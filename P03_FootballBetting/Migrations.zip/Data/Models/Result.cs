﻿namespace P03_FootballBetting.Data.Models
{
    public enum Result
    {
        HomeTeam = 1,
        AwayTeam = 2,
        Draw = 3
    }
}